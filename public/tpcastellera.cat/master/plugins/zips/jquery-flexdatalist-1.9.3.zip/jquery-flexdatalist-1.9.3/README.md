jQuery.Flexdatalist
======

Flexdatalist is (another) jQuery autocomplete plugin with support for <code>&lt;datalist&gt;</code>. Check the documentation page to see the plugin in action.

## Demo & Documentation ##

Check out the [examples and documentation](http://projects.sergiodinislopes.pt/flexdatalist/) page.

### License
Flexdatalist is licensed under the [MIT license](http://opensource.org/licenses/MIT).
Copyright (c) 2016 [Sérgio Dinis Lopes](http://github.com/sergiodlopes)