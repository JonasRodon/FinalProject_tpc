const Castell = require('../../../models/Castell')
module.exports = (req, res) => {
  const { itpc } = req.params
        // Castell.find({'position.itpc': {$eq: itpc}})
        //   .then(castell => res.render('castell', { castell }))
        //   .catch(err => { throw err })

  Castell.find({ 'position.itpc': itpc })
        .then(castell => {
          castell.details.gamma = gamma(castell.details.gamma)
          console.log(castell.details.gamma)
        })
        .then(castell => {
          castell.parts.pinya = parts(castell.parts.pinya)
          console.log(castell.parts.pinya)
        })
        .then(castell => {
          castell.parts.tronc = parts(castell.parts.tronc)
          console.log(castell.parts.tronc)
        })
        .then(castell => {
          castell.parts.pom = parts(castell.parts.pom)
          console.log(castell.parts.pom)
        })
        .then(castell => {
          castell.parts.folre = parts(castell.parts.folre)
          console.log(castell.parts.folre)
        })
        .then(castell => {
          castell.parts.manilles = parts(castell.parts.manilles)
          console.log(castell.parts.manilles)
        })
        .then(castell => res.render('castell', { castell }))
        .catch(err => {
          throw err
        })
}

function gamma (g) {
  var result
  switch (g) {
    case 6:
      result = '#008EB0'
      break
    case 7:
      result = '#4CBB7D'
      break
    case 8:
      result = '#FCB033'
      break
    case 9:
      result = '#F15D4D'
      break
    case 'extra':
      result = '#AD8EC3'
      break
    default:
      result = '#FFFFFF'
  }
  return result
}

function parts (p) {
  if (p === 1) {
    return p + 'casteller'
  } else if (p < 1 && p !== 'sense') {
    return p + 'castellers'
  }
}
