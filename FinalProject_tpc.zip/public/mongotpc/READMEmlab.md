To connect using the mongo shell:
mongo ds139430.mlab.com:39430/dbtpc -u <dbuser> -p <dbpassword>
To connect using a driver via the standard MongoDB URI (what's this?):

mongodb://<dbuser>:<dbpassword>@ds139430.mlab.com:39430/dbtpc
